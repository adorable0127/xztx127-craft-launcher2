﻿using System.Windows;
using System.Windows.Controls;
using XCL2.App.Services;

namespace XCL2.App.Views;

/// <summary>
/// 主流程通知类弹窗的分类。跟原来 MessageBoxImage 的用途一样——只影响图标和一点点配色
/// 强调（比如 Error 用 DangerBrush 强调标题），不影响弹窗结构本身。
/// </summary>
public enum XclMessageKind
{
    Info,
    Success,
    Warning,
    Error,
}

/// <summary>
/// 按钮方案，对应原来 MessageBoxButton 里实际用到的几种。YesNoCancel 是后续补充的——
/// DownloadCenterPage.PromptSaveDirectory("是"=用默认目录/"否"=另选目录/"取消"=放弃下载)
/// 这个三态选择在最初写这个类时项目里还没有实际调用点，所以当时没实现；现在这个是唯一
/// 用到三态的地方，才补上，避免引入用不到的复杂度这条原则被违反。
/// </summary>
public enum XclMessageButtons
{
    OK,
    OKCancel,
    YesNo,
    YesNoCancel,
}

/// <summary>
/// YesNoCancel 弹窗的结果——三态场景下 bool? 已经不够用（true/false/null 三个值全部
/// 有实际业务含义：是/否/取消，而不是"取消=没有点任何按钮就关闭"那种默认语义），
/// 所以单独定义一个结果枚举，跟 System.Windows.MessageBoxResult 的这三个成员同名，
/// 方便照着原来的 MessageBoxResult.Yes/No/Cancel 判断逻辑直接改写用法。
/// </summary>
public enum XclMessageResult
{
    Yes,
    No,
    Cancel,
}

/// <summary>关闭按钮"下载/启动进行中"四选一提示专用结果，见 MessageBoxDialog.ShowFourChoice。</summary>
public enum XclFourChoiceResult
{
    Cancel,
    Close,
    Minimize,
    Tray,
}

/// <summary>触屏模式下关闭启动器的专用四选一结果，见 MessageBoxDialog.ShowTouchModeCloseChoice。
/// 之所以不复用 XclFourChoiceResult：那一套的"关闭/最小化/托盘"语义是给"下载/启动中"场景
/// 设计的，跟触屏模式这里"关闭全部游戏 / 只摘掉悬浮层留游戏在跑"的选项含义完全不同，
/// 硬凑同一个枚举会让调用方看着名字猜不出这次到底是哪种关闭。</summary>
public enum XclTouchCloseChoiceResult
{
    Cancel,
    CloseAllIncludingGame,
    Tray,
    CloseLauncherAndOverlayOnly,
}

/// <summary>“千万别点那按钮”专用四选一结果：取消 + 三个同名“确定”。</summary>
public enum XclDangerFourChoiceResult
{
    Cancel,
    Confirm1,
    Confirm2,
    Confirm3,
}

/// <summary>
/// 通用消息提示弹窗 —— 进程内 Overlay 版本的 MessageBox.Show()替代品。
///
/// ===== 为什么要做这个 =====
/// 系统原生 MessageBox 是 Win32 对话框，样式完全由操作系统决定，不认识本项目的
/// PanelBrush/AccentBrush 这套皮肤系统——用户切换到粉色皮肤后，主界面全是粉色，
/// 结果"游戏已启动"这种最常见的提示弹窗跳出来却是一个跟皮肤毫不相关的系统灰白框，
/// 观感割裂，也是"一体化启动器"体验里最显眼的短板之一。这个类提供的静态方法
/// （Show/ShowInfo/ShowWarning/ShowError/ShowConfirm）签名尽量贴近原来的
/// MessageBox.Show()，方便逐步替换调用点。
///
/// ===== 使用建议（给下一个改动这份代码的人）=====
/// 项目里还有大量 MessageBox.Show(...) 调用点没有全部替换完——这是有意为之的分阶段
/// 迁移，不是遗漏：这一轮优先替换的是"游戏启动成功""需要登录账户""错误提示"
/// （ErrorPresenter.ShowFriendlyError，几乎是全项目错误弹窗的统一出口）以及"调试信息"
/// 相关的弹窗，因为这些是玩家最高频会看到的几类。其余分散在设置页/服务器管理等次要
/// 操作确认框里的 MessageBox.Show 调用，后续按同样的套路（把 MessageBox.Show(...) 换成
/// XclMessageBox.Show(...)，参数基本一一对应）逐步替换即可，不需要一次性改完。
/// （注：类名实际是 MessageBoxDialog，不是文档里早先设想的 XclMessageBox；调用点一律
/// 写 MessageBoxDialog.ShowXxx(...)，枚举名 XclMessageKind/XclMessageButtons/XclMessageResult
/// 保留 Xcl 前缀不受影响。）
/// 三态的 YesNoCancel（见 XclMessageButtons.YesNoCancel/XclMessageResult/ShowYesNoCancel）
/// 是后来在替换 DownloadCenterPage.PromptSaveDirectory 时才补上的，之前项目里没有
/// 实际调用点用到三态，所以最初没实现；这也是"按需补充，不预先引入用不到的复杂度"
/// 这套原则的一次实际应用。
/// </summary>
public partial class MessageBoxDialog : OverlayDialogControl
{
    /// <summary>用户点击的是哪个按钮（用于 YesNo/OKCancel 场景）。true=Yes/OK，
    /// false=No/Cancel，null=没有点任何按钮就关闭了（比如按 Esc/点遮罩）。</summary>
    public bool? Result { get; private set; }

    /// <summary>YesNoCancel 场景专用的三态结果，见 XclMessageResult 注释。只有用
    /// XclMessageButtons.YesNoCancel 弹出时才会被设置为 Yes/No/Cancel 三者之一；
    /// 用户按 Esc/点遮罩关闭（没有点任何按钮）时归类为 Cancel——跟原生 MessageBox
    /// 在 YesNoCancel 模式下"叉掉窗口"等价于点了 Cancel 的行为一致。</summary>
    public XclMessageResult Result3 { get; private set; } = XclMessageResult.Cancel;

    /// <summary>四选一场景专用结果（目前只有关闭按钮的"下载/启动进行中"提示用到），
    /// 用法跟 Result3 一样：只有走 ShowFourChoice 弹出时才会被设置。</summary>
    public XclFourChoiceResult Result4 { get; private set; } = XclFourChoiceResult.Cancel;

    /// <summary>“千万别点那按钮”专用结果。</summary>
    public XclDangerFourChoiceResult DangerResult4 { get; private set; } = XclDangerFourChoiceResult.Cancel;

    /// <summary>触屏模式关闭确认专用结果，见 ShowTouchModeCloseChoice。</summary>
    public XclTouchCloseChoiceResult TouchCloseResult { get; private set; } = XclTouchCloseChoiceResult.Cancel;

    private MessageBoxDialog(string message, string title, XclMessageKind kind, XclMessageButtons buttons)
    {
        InitializeComponent();

        TitleText.Text = title;
        MessageText.Text = message;
        IconText.Text = kind switch
        {
            XclMessageKind.Success => "✔",
            XclMessageKind.Warning => "⚠",
            XclMessageKind.Error => "✖",
            _ => "ℹ",
        };
        IconText.Foreground = kind switch
        {
            XclMessageKind.Success => (System.Windows.Media.Brush)FindResource("SuccessTextBrush"),
            XclMessageKind.Warning => (System.Windows.Media.Brush)FindResource("WarningTextBrush"),
            XclMessageKind.Error => (System.Windows.Media.Brush)FindResource("DangerBrush"),
            _ => (System.Windows.Media.Brush)FindResource("AccentBrush"),
        };

        BuildButtons(buttons);
    }

    private void BuildButtons(XclMessageButtons buttons)
    {
        switch (buttons)
        {
            case XclMessageButtons.OK:
                ButtonPanel.Children.Add(MakeButton("确定", true, isPrimary: true, isDefault: true));
                break;
            case XclMessageButtons.OKCancel:
                ButtonPanel.Children.Add(MakeButton("取消", false, isPrimary: false, isDefault: false));
                ButtonPanel.Children.Add(MakeButton("确定", true, isPrimary: true, isDefault: true));
                break;
            case XclMessageButtons.YesNo:
                ButtonPanel.Children.Add(MakeButton("否", false, isPrimary: false, isDefault: false));
                ButtonPanel.Children.Add(MakeButton("是", true, isPrimary: true, isDefault: true));
                break;
            case XclMessageButtons.YesNoCancel:
                // 三个按钮从左到右：取消/否/是——跟原生 MessageBox 在 Windows 上的
                // 从左到右顺序（是/否/取消）刻意不同，这里沿用本项目其它 OKCancel/YesNo
                // 场景"次要操作靠左、主操作靠右且带 PrimaryButton 高亮"的既有布局习惯，
                // 保持这个类内部风格统一，而不是逐字照搬系统对话框的布局。
                ButtonPanel.Children.Add(MakeButton3("取消", XclMessageResult.Cancel, isPrimary: false, isDefault: false));
                ButtonPanel.Children.Add(MakeButton3("否", XclMessageResult.No, isPrimary: false, isDefault: false));
                ButtonPanel.Children.Add(MakeButton3("是", XclMessageResult.Yes, isPrimary: true, isDefault: true));
                break;
        }
    }

    private Button MakeButton(string content, bool result, bool isPrimary, bool isDefault)
    {
        var btn = new Button
        {
            Content = content,
            Padding = new Thickness(20, 8, 20, 8),
            Margin = new Thickness(8, 0, 0, 0),
            IsDefault = isDefault,
            Style = isPrimary ? (Style)FindResource("PrimaryButton") : (Style)FindResource("SecondaryButton"),
        };
        btn.Click += (_, _) =>
        {
            Result = result;
            CloseWith(result);
        };
        return btn;
    }

    /// <summary>YesNoCancel 专用的按钮工厂：跟 MakeButton 的差异只在于写入 Result3
    /// （三态）而不是 Result（bool?），并且 CloseWith 统一传 null——YesNoCancel 场景下
    /// 调用方应该读 Result3，不应该继续依赖 bool? 的 IOverlayDialog.RequestClose 语义,
    /// 这里传 null 只是满足 CloseWith 的签名要求，不代表"没有选择"。</summary>
    private Button MakeButton3(string content, XclMessageResult result, bool isPrimary, bool isDefault)
    {
        var btn = new Button
        {
            Content = content,
            Padding = new Thickness(20, 8, 20, 8),
            Margin = new Thickness(8, 0, 0, 0),
            IsDefault = isDefault,
            Style = isPrimary ? (Style)FindResource("PrimaryButton") : (Style)FindResource("SecondaryButton"),
        };
        btn.Click += (_, _) =>
        {
            Result3 = result;
            CloseWith(null);
        };
        return btn;
    }

    // ===== 静态入口：签名尽量贴近 System.Windows.MessageBox.Show，方便替换调用点 =====

    /// <summary>等价于 MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information)。</summary>
    public static void ShowInfo(string message, string title = "提示") => Show(message, title, XclMessageKind.Info, XclMessageButtons.OK);

    /// <summary>ShowInfo 的 async/await 版本。专供已经身处 async 方法（尤其是
    /// await Task.Run(...) 之后的延续里）的调用点使用——见 MainWindow.
    /// ScanMinecraftFoldersInBackgroundAsync 上的注释：在异步延续内部调用
    /// ShowModal（内部手动 PushFrame 起一个局部消息泵）容易跟外层已经在排队的
    /// SynchronizationContext 延续相互竞争，导致弹窗关闭后 Overlay 没能正常收起、
    /// 卡住吃掉后续所有点击。这个方法改用 ShowModalAsync + await，不再嵌套消息泵。</summary>
    public static Task ShowInfoAsync(string message, string title = "提示")
        => ShowAsync(message, title, XclMessageKind.Info, XclMessageButtons.OK);

    /// <summary>等价于 MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information)，
    /// 专用于"操作成功完成"类通知（游戏启动成功、下载完成等），图标用 ✔ 而不是 ℹ，
    /// 视觉上更明确地传达"这是好消息"。</summary>
    public static void ShowSuccess(string message, string title = "成功") => Show(message, title, XclMessageKind.Success, XclMessageButtons.OK);

    /// <summary>ShowSuccess 的 async/await 版本，同 ShowInfoAsync 的适用场景。</summary>
    public static Task ShowSuccessAsync(string message, string title = "成功")
        => ShowAsync(message, title, XclMessageKind.Success, XclMessageButtons.OK);

    /// <summary>等价于 MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Warning)。</summary>
    public static void ShowWarning(string message, string title = "提示") => Show(message, title, XclMessageKind.Warning, XclMessageButtons.OK);

    /// <summary>ShowWarning 的 async/await 版本，同 ShowInfoAsync 的适用场景。</summary>
    public static Task ShowWarningAsync(string message, string title = "提示")
        => ShowAsync(message, title, XclMessageKind.Warning, XclMessageButtons.OK);

    /// <summary>等价于 MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Error)。</summary>
    public static void ShowError(string message, string title = "出了点问题") => Show(message, title, XclMessageKind.Error, XclMessageButtons.OK);

    /// <summary>ShowError 的 async/await 版本，同 ShowInfoAsync 的适用场景。</summary>
    public static Task ShowErrorAsync(string message, string title = "出了点问题")
        => ShowAsync(message, title, XclMessageKind.Error, XclMessageButtons.OK);

    /// <summary>等价于 MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question)，
    /// 返回 true 表示用户点了"是"。</summary>
    public static bool ShowConfirm(string message, string title = "确认")
        => Show(message, title, XclMessageKind.Info, XclMessageButtons.YesNo) == true;

    /// <summary>等价于 MessageBox.Show(message, title, MessageBoxButton.YesNoCancel, MessageBoxImage.Question)，
    /// 返回值直接对应原来的 MessageBoxResult.Yes/No/Cancel 三态，调用方原来怎么判断
    /// choice == MessageBoxResult.Xxx，现在就怎么判断 result == XclMessageResult.Xxx。</summary>
    public static XclMessageResult ShowYesNoCancel(string message, string title = "确认")
    {
        var dlg = new MessageBoxDialog(message, title, XclMessageKind.Info, XclMessageButtons.YesNoCancel);
        OverlayDialogService.ShowModal(dlg);
        return dlg.Result3;
    }

    /// <summary>
    /// 三选一弹窗，按钮文案完全自定义——ShowYesNoCancel 的按钮文案固定是"取消/否/是"，
    /// 不满足"返回重新确认 / 使用基本模式 / 退出软件"这类每个按钮都需要说清楚具体动作
    /// 的场景（用"是/否/取消"根本看不出来点哪个是什么意思）。三个按钮从左到右依次对应
    /// option1（次要，靠左）/ option2（次要）/ option3（主操作，高亮，靠右，默认按钮），
    /// 布局风格跟 ShowYesNoCancel 保持一致；返回值同样复用 XclMessageResult 三态，
    /// 只是把 Cancel/No/Yes 分别重新解释成 option1/option2/option3，调用方按位置对应即可，
    /// 不需要关心枚举名字面意思跟按钮文案是否匹配。用户按 Esc/点遮罩关闭（没有点任何按钮）
    /// 时归为 Cancel（即 option1 那一档），语义上视为"什么都没选、维持现状"。
    /// </summary>
    public static XclMessageResult ShowThreeChoice(string message, string title, string option1, string option2, string option3)
    {
        var dlg = new MessageBoxDialog(message, title, XclMessageKind.Info, XclMessageButtons.OK);
        dlg.ButtonPanel.Children.Clear();
        dlg.ButtonPanel.Children.Add(dlg.MakeButton3(option1, XclMessageResult.Cancel, isPrimary: false, isDefault: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeButton3(option2, XclMessageResult.No, isPrimary: false, isDefault: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeButton3(option3, XclMessageResult.Yes, isPrimary: true, isDefault: true));
        OverlayDialogService.ShowModal(dlg);
        return dlg.Result3;
    }

    /// <summary>
    /// 两按钮自定义文案确认弹窗——ShowConfirm 的按钮文案固定是"否/是"，不满足需要
    /// 明确动作描述（比如"进入/返回"）的场景。rightIsPrimary 控制哪一侧使用高亮的
    /// PrimaryButton 样式并作为默认按钮（Enter 触发）；对于"不建议进入"这类场景，
    /// 调用方应该把更安全的那个按钮（一般是"返回"）设为 primary，避免用户误按 Enter
    /// 就真的进入了有问题的功能。返回 true 表示点了右侧（rightText）按钮。
    /// </summary>
    public static bool ShowCustomYesNo(string message, string title, string leftText, string rightText,
        bool rightIsPrimary = true, XclMessageKind kind = XclMessageKind.Warning)
    {
        var dlg = new MessageBoxDialog(message, title, kind, XclMessageButtons.OK);
        dlg.ButtonPanel.Children.Clear();
        dlg.ButtonPanel.Children.Add(dlg.MakeButton(leftText, true, isPrimary: !rightIsPrimary, isDefault: !rightIsPrimary));
        dlg.ButtonPanel.Children.Add(dlg.MakeButton(rightText, false, isPrimary: rightIsPrimary, isDefault: rightIsPrimary));
        return OverlayDialogService.ShowModal(dlg) == true;
    }

    /// <summary>四选一专用按钮工厂，用法同 MakeButton3。</summary>
    private Button MakeButton4(string content, XclFourChoiceResult result, bool isPrimary, bool isDefault)
    {
        var btn = new Button
        {
            Content = content,
            Padding = new Thickness(16, 8, 16, 8),
            Margin = new Thickness(6, 0, 0, 0),
            IsDefault = isDefault,
            Style = isPrimary ? (Style)FindResource("PrimaryButton") : (Style)FindResource("SecondaryButton"),
        };
        btn.Click += (_, _) =>
        {
            Result4 = result;
            CloseWith(null);
        };
        return btn;
    }

    /// <summary>关闭按钮"下载/启动进行中"专用四选一提示：取消 / 关闭 / 最小化 / 返回任务栏托盘。
    /// 用户按 Esc/点遮罩关闭时归为 Cancel（什么都不做，维持窗口原样，跟点"取消"等价）。</summary>
    public static XclFourChoiceResult ShowFourChoice(string message, string title,
        string cancelText, string closeText, string minimizeText, string trayText)
    {
        var dlg = new MessageBoxDialog(message, title, XclMessageKind.Warning, XclMessageButtons.OK);
        dlg.ButtonPanel.Children.Clear();
        dlg.ButtonPanel.Children.Add(dlg.MakeButton4(cancelText, XclFourChoiceResult.Cancel, isPrimary: false, isDefault: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeButton4(trayText, XclFourChoiceResult.Tray, isPrimary: false, isDefault: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeButton4(minimizeText, XclFourChoiceResult.Minimize, isPrimary: false, isDefault: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeButton4(closeText, XclFourChoiceResult.Close, isPrimary: true, isDefault: true));
        OverlayDialogService.ShowModal(dlg);
        return dlg.Result4;
    }

    /// <summary>触屏模式下点关闭按钮的专用四选一提示：正在用触屏模式玩游戏时关闭启动器，
    /// 悬浮层会跟着启动器一起消失，玩家手上一秒还能戳的虚拟按键下一秒就没了——这跟平时
    /// "点叉号无非是关不关游戏"的心理预期差得比较远，所以单独截住，不走 DefaultCloseAction
    /// 那套默认行为，每次都明确问一遍。
    ///
    /// 四个选项对应四种完全不同的后果：
    /// 取消 —— 什么都不做，回到刚才的状态。
    /// 关闭所有(包括游戏) —— 启动器、悬浮层、游戏进程一起结束，最干净的退出方式。
    /// 返回托盘 —— 启动器、悬浮层、游戏全部继续在后台/前台跑，只是把主窗口藏进系统托盘，
    ///           触屏操作不受任何影响。
    /// 关闭XCL和虚拟按键 —— 只结束启动器进程和悬浮层，游戏本身继续单独运行；代价是虚拟按键
    ///           消失了，触屏没法再操作，只有接了实体键鼠才能继续玩。</summary>
    public static XclTouchCloseChoiceResult ShowTouchModeCloseChoice(string message, string title,
        string cancelText, string closeAllText, string trayText, string closeLauncherOnlyText)
    {
        var dlg = new MessageBoxDialog(message, title, XclMessageKind.Warning, XclMessageButtons.OK);
        dlg.ButtonPanel.Children.Clear();
        dlg.ButtonPanel.Children.Add(dlg.MakeTouchCloseButton(cancelText, XclTouchCloseChoiceResult.Cancel, isPrimary: false, isDefault: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeTouchCloseButton(closeLauncherOnlyText, XclTouchCloseChoiceResult.CloseLauncherAndOverlayOnly, isPrimary: false, isDefault: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeTouchCloseButton(trayText, XclTouchCloseChoiceResult.Tray, isPrimary: false, isDefault: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeTouchCloseButton(closeAllText, XclTouchCloseChoiceResult.CloseAllIncludingGame, isPrimary: true, isDefault: true));
        OverlayDialogService.ShowModal(dlg);
        return dlg.TouchCloseResult;
    }

    private Button MakeTouchCloseButton(string content, XclTouchCloseChoiceResult result, bool isPrimary, bool isDefault)
    {
        var btn = new Button
        {
            Content = content,
            Padding = new Thickness(16, 8, 16, 8),
            Margin = new Thickness(6, 0, 0, 0),
            IsDefault = isDefault,
            Style = isPrimary ? (Style)FindResource("PrimaryButton") : (Style)FindResource("SecondaryButton"),
        };
        btn.Click += (_, _) =>
        {
            TouchCloseResult = result;
            CloseWith(null);
        };
        return btn;
    }

    /// <summary>“千万别点那按钮”专用四选一风险提示。前三个按钮（取消、确定、确定）
    /// 使用普通次要按钮样式，最后一个“确定”使用危险红色；提示正文也使用危险红色。
    /// 四个按钮都不设默认按钮，避免用户只按 Enter 就误触。
    /// </summary>
    public static XclDangerFourChoiceResult ShowDangerFourChoice(string message, string title,
        string cancelText = "取消", string confirm1Text = "确定", string confirm2Text = "确定", string confirm3Text = "确定")
    {
        var dlg = new MessageBoxDialog(message, title, XclMessageKind.Error, XclMessageButtons.OK);
        dlg.MessageText.Foreground = (System.Windows.Media.Brush)dlg.FindResource("DangerBrush");
        dlg.ButtonPanel.Children.Clear();
        dlg.ButtonPanel.Children.Add(dlg.MakeDangerChoiceButton(cancelText, XclDangerFourChoiceResult.Cancel, isDanger: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeDangerChoiceButton(confirm1Text, XclDangerFourChoiceResult.Confirm1, isDanger: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeDangerChoiceButton(confirm2Text, XclDangerFourChoiceResult.Confirm2, isDanger: false));
        dlg.ButtonPanel.Children.Add(dlg.MakeDangerChoiceButton(confirm3Text, XclDangerFourChoiceResult.Confirm3, isDanger: true));
        OverlayDialogService.ShowModal(dlg);
        return dlg.DangerResult4;
    }

    private Button MakeDangerChoiceButton(string content, XclDangerFourChoiceResult result, bool isDanger)
    {
        var btn = new Button
        {
            Content = content,
            Padding = new Thickness(16, 8, 16, 8),
            Margin = new Thickness(6, 0, 0, 0),
            IsDefault = false,
            Style = (Style)FindResource(isDanger ? "PrimaryButton" : "SecondaryButton"),
        };
        if (isDanger)
        {
            var danger = (System.Windows.Media.Brush)FindResource("DangerBrush");
            btn.Background = danger;
            btn.BorderBrush = danger;
            btn.Foreground = System.Windows.Media.Brushes.White;
        }
        btn.Click += (_, _) =>
        {
            DangerResult4 = result;
            CloseWith(null);
        };
        return btn;
    }

    /// <summary>最通用的入口，其它 ShowXxx 静态方法都是对这个的语义化包装。</summary>
    public static bool? Show(string message, string title, XclMessageKind kind, XclMessageButtons buttons)
    {
        var dlg = new MessageBoxDialog(message, title, kind, buttons);
        return OverlayDialogService.ShowModal(dlg);
    }

    /// <summary>Show 的 async/await 版本，其它 ShowXxxAsync 静态方法都是对这个的语义化包装。
    /// 见 ShowInfoAsync 上的注释：专供调用点自己已经身处 async 延续（比如
    /// await Task.Run(...) 之后）时使用，避免嵌套 PushFrame 消息泵。</summary>
    public static Task ShowAsync(string message, string title, XclMessageKind kind, XclMessageButtons buttons)
    {
        var dlg = new MessageBoxDialog(message, title, kind, buttons);
        return OverlayDialogService.ShowModalAsync(dlg);
    }
}
