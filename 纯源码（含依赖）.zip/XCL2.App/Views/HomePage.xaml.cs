using System;
using System.Linq;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Input;
using XCL2.App.Services;

namespace XCL2.App.Views;

/// <summary>
/// 首页：磁贴总控台。原本"普通/高手模式"这个状态的唯一读写入口在 SettingsPage
/// （cfg.AdvancedMode，见 AdvancedModeCheck_Changed），现在首页右上角也加了一个同款开关
/// 方便快速切换，两处操作的是同一个配置项、同一份保存逻辑，不是各自独立的状态。
///
/// 「模式设置」（深/浅色）和「自动循环」两个按钮同理：都是直接读写 AppConfig 里对应的
/// 字段，点击立即保存并生效，不需要用户去「设置」页点"保存设置"。
/// </summary>
public partial class HomePage : UserControl
{
    private readonly MainWindow _owner;

    private bool _guestToggleInitializing;
    private bool _modeToggleInitializing;
    private bool _darkModeToggleInitializing;
    private bool _autoThemeToggleInitializing;
    private bool _followSystemThemeToggleInitializing;
    private bool _simplifiedToggleInitializing;
    private Action? _onLanguageChanged;
    private bool _previewToggleSyncing;

    /// <summary>
    /// 标记这份 HomePage 实例是不是"重启进入的新界面预览"那一次——也就是 MainWindow 本身
    /// 就是用 --preview-session 启动、把这份 HomePage 直接当成首页放进 MainContent 的那种，
    /// 跟旧版"套一层独立浮动窗口"承载预览的方案是两回事：这种情况下侧边栏、标题栏都是
    /// MainWindow 本来就有的那一套，天然可点、天然有侧边栏，不需要也不应该再额外禁用/锁定
    /// PreviewToggle。见 MainWindow.RequestPreviewModeRestart / ShowExperimentalPreview。
    /// </summary>
    private bool _isMainWindowPreviewSession;

    public HomePage(MainWindow owner)
    {
        _owner = owner;
        InitializeComponent();

        // 从配置里同步访客模式的当前状态；用 _guestToggleInitializing 避免这一步触发
        // GuestModeToggle_Changed（那里会去改配置+清理会话文件，只有用户手动点击才应该触发）。
        _guestToggleInitializing = true;
        GuestModeToggle.IsChecked = _owner.ConfigService.Config.GuestModeEnabled;
        UpdateGuestModeToggleText();
        _guestToggleInitializing = false;

        _simplifiedToggleInitializing = true;
        SimplifiedModeToggle.IsChecked = _owner.ConfigService.Config.SimplifiedModeEnabled;
        _simplifiedToggleInitializing = false;

        RefreshModeToggle();
        RefreshThemeToggles();
        ApplyRestrictedModeGating(_owner.ConfigService.Config.RestrictedMode);

        UpdateLanguageEntryButtonText();
        // LocalizationService.LanguageChanged 是静态事件：每 new 一次 HomePage 就多挂一个订阅，
        // 之前没有对应的 -= 会一直泄漏下去（比如新界面预览关掉之后，这个委托还挂在静态事件上，
        // 指向一个已经没有可视化树的实例）。现在存成具名委托，在 Unloaded 时摘掉。
        _onLanguageChanged = () => UpdateLanguageEntryButtonText();
        LocalizationService.LanguageChanged += _onLanguageChanged;
        Unloaded += (_, _) => LocalizationService.LanguageChanged -= _onLanguageChanged;

        // 愚人节彩蛋 3 号（鼠标靠近就乱窜）+ 8 号（磁贴乱跳）：平时（非 4 月 1 日）这个调用
        // 内部全部是空操作，见 AprilFoolsUi 类注释。
        AprilFoolsUi.AttachHomeTileEffects(TileGrid, LaunchTile, QuickStartTile);

        HomeSearchResultsPopup.Closed += (_, _) => HomeSearchResultsList.SelectedIndex = -1;
    }

    // ===== 首页顶部搜索框：导航到应用内所有页面 =====
    // 索引来自 _owner.GetHomeSearchEntries()（定义在 MainWindow 里，跟侧边栏导航按钮共用
    // 同一套 NavigateToXxx() 跳转方法），这里只负责按输入文本筛选、展示结果列表、
    // 处理点击/回车/上下键选中后调用 _owner.NavigateByHomeSearchTitle(title) 完成跳转。

    private void HomeSearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var keyword = HomeSearchBox.Text?.Trim() ?? "";
        HomeSearchPlaceholder.Visibility = keyword.Length == 0 ? Visibility.Visible : Visibility.Collapsed;

        if (keyword.Length == 0)
        {
            HomeSearchResultsPopup.IsOpen = false;
            return;
        }

        var matches = _owner.GetHomeSearchEntries()
            .Where(entry => entry.Title.Contains(keyword, StringComparison.OrdinalIgnoreCase)
                             || entry.Keywords.Contains(keyword, StringComparison.OrdinalIgnoreCase))
            .Select(entry => entry.Title)
            .ToList();

        HomeSearchResultsList.ItemsSource = matches;
        HomeSearchResultsPopup.IsOpen = matches.Count > 0;
    }

    private void HomeSearchBox_GotFocus(object sender, RoutedEventArgs e) => HomeSearchPlaceholder.Visibility = string.IsNullOrEmpty(HomeSearchBox.Text) ? Visibility.Visible : Visibility.Collapsed;

    private void HomeSearchBox_LostFocus(object sender, RoutedEventArgs e)
    {
        // 延迟关闭：直接在这里关 Popup 会先于 ListBox 的点击事件触发，导致点结果永远点不到。
        // Popup 自带的 StaysOpen="False" 已经会在点击外部区域时自动关闭，这里不用额外处理。
    }

    private void HomeSearchBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Down && HomeSearchResultsList.Items.Count > 0)
        {
            HomeSearchResultsList.Focus();
            HomeSearchResultsList.SelectedIndex = 0;
            e.Handled = true;
        }
        else if (e.Key == Key.Enter && HomeSearchResultsList.Items.Count > 0)
        {
            NavigateToHomeSearchResult(HomeSearchResultsList.Items[0] as string);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            HomeSearchResultsPopup.IsOpen = false;
        }
    }

    private void HomeSearchResultsList_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && HomeSearchResultsList.SelectedItem is string title)
        {
            NavigateToHomeSearchResult(title);
            e.Handled = true;
        }
    }

    private void HomeSearchResultsList_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (HomeSearchResultsList.SelectedItem is string title)
        {
            NavigateToHomeSearchResult(title);
        }
    }

    private void NavigateToHomeSearchResult(string? title)
    {
        if (string.IsNullOrEmpty(title)) return;
        HomeSearchResultsPopup.IsOpen = false;
        HomeSearchBox.Text = "";
        _owner.NavigateByHomeSearchTitle(title);
    }

    /// <summary>语言胶囊文字：Str_Lang_EntryButton 里的「*」通配符替换为当前语言的本地名，
    /// 例如「（简体中文（Microsoft）/简体中文（Microsoft）/选择语言）」。三个语言文件里这条
    /// 都是模板「（*/*/选择语言）」，不随语言翻译，运行时这里统一填当前语言名。</summary>
    private void UpdateLanguageEntryButtonText()
    {
        var template = Application.Current.FindResource("Str_Lang_EntryButton") as string
                       ?? "（*/*/选择语言）";
        var current = System.Linq.Enumerable.FirstOrDefault(
            LocalizationService.SupportedLanguages,
            l => l.Code == LocalizationService.CurrentLanguageCode);
        var name = current?.NativeName ?? LocalizationService.CurrentLanguageCode;
        LanguageEntryButtonText.Text = template.Replace("*", name);
    }

    /// <summary>基本模式（RestrictedMode=true）下的功能门控。
    /// 右上角这一排按钮里，「语言」和「访客模式」两个允许在基本模式下继续使用（语言是
    /// 界面可用性的前提，访客模式是新手最常用的临时游玩方式），其余「模式设置」（深/浅色）、
    /// 「自动循环」、「普通模式/高级模式切换」保持置灰——这几个不在侧边栏导航按钮之列，
    /// MainWindow.ApplyRestrictedModeGating 单独没法碰到，靠这个方法从外面调用。
    /// 磁贴总控台里，「账户管理」磁贴允许使用；「下载中心」「服务器管理」「设置」三个磁贴
    /// 在基本模式下置灰（这些是进阶功能，跟侧边栏对应导航按钮的受限状态保持一致）；
    /// 「启动游戏」「一键开始游戏」两个磁贴不受影响，本来就不在受限范围内。
    /// 构造函数里也会用当前配置调一次，保证"从受限状态启动、首页第一次显示"就已经是对的，
    /// 不用等用户先切一次页。只置灰不隐藏，跟侧边栏导航按钮的处理方式保持一致
    /// （用户随时能看见还有哪些功能存在）。</summary>
    public void ApplyRestrictedModeGating(bool restricted)
    {
        DarkModeToggle.IsEnabled = !restricted;
        AutoThemeCycleToggle.IsEnabled = !restricted;
        ModeToggle.IsEnabled = !restricted;

        DownloadTile.IsEnabled = !restricted;
        ServerManagerTile.IsEnabled = !restricted;
        SettingsTile.IsEnabled = !restricted;
    }

    /// <summary>
    /// 从配置里重新读取 cfg.AdvancedMode 并同步到 ModeToggle 的勾选状态/文案，不触发保存。
    /// 除了构造函数第一次调用，还需要在"从设置页切回首页"时调用一次——用户可能刚在设置页
    /// 切换过模式，首页这份按钮的显示不应该是切页面之前的旧状态。见 MainWindow.ShowHome。
    /// </summary>
    public void RefreshModeToggle()
    {
        _modeToggleInitializing = true;
        ModeToggle.IsChecked = _owner.ConfigService.Config.AdvancedMode;
        UpdateModeToggleText();
        _modeToggleInitializing = false;
        RefreshTileOrder();
    }

    /// <summary>
    /// 需求：普通模式下把"启动游戏"和"一键开始游戏"这两个磁贴的位置互换（高级模式不用管，
    /// 保持原来的顺序）——普通模式的用户大多是新手，更需要"一键开始游戏"这种全自动向导，
    /// 换到磁贴总控台第一格（左上角，最先看到、最方便点到的位置）；高级模式用户通常已经
    /// 自己配置好版本/账户，"启动游戏"这个直接启动的磁贴放在第一格更符合高级模式的使用习惯，
    /// 所以高级模式下维持 XAML 里写死的原始顺序不动。
    ///
    /// UniformGrid 按 Children 集合顺序自动填格子，交换顺序只需要把这两个 Button 在
    /// Children 里的索引对调；但两者的 Margin 是跟\"当前所在格子的行列位置\"绑定的
    /// （比如第一格是 Margin="0,0,10,10"，第四格是 Margin="0,0,10,0"，右边距/下边距取决于
    /// 是不是最后一列/最后一行），所以调整索引的同时必须把 Margin 也交换一次，否则两个磁贴
    /// 会带着"错的格子"该有的间距挪到"对的格子"里，视觉上出现多余/缺失的间隙。
    /// 这个方法是幂等的：可以在同一个 HomePage 实例上被多次调用（比如反复来回切模式），
    /// 每次都先用 IndexOf 现查两者当前的实际索引，不依赖"只能交换一次"的假设。
    /// </summary>
    private void RefreshTileOrder()
    {
        var advanced = _owner.ConfigService.Config.AdvancedMode;

        var launchIndex = TileGrid.Children.IndexOf(LaunchTile);
        var quickStartIndex = TileGrid.Children.IndexOf(QuickStartTile);
        if (launchIndex < 0 || quickStartIndex < 0) return;

        // 普通模式：一键开始游戏在前（索引更小）；高级模式：启动游戏在前。
        // 如果当前顺序已经符合目标模式的要求，不用再交换（避免同一模式下重复调用时
        // 把已经交换好的顺序又换回去）。
        var alreadyCorrectOrder = advanced ? launchIndex < quickStartIndex : quickStartIndex < launchIndex;
        if (alreadyCorrectOrder) return;

        var launchMargin = LaunchTile.Margin;
        var quickStartMargin = QuickStartTile.Margin;

        TileGrid.Children.RemoveAt(Math.Max(launchIndex, quickStartIndex));
        TileGrid.Children.RemoveAt(Math.Min(launchIndex, quickStartIndex));

        var firstSlotIndex = Math.Min(launchIndex, quickStartIndex);
        var (first, second) = advanced ? (LaunchTile, QuickStartTile) : (QuickStartTile, LaunchTile);
        TileGrid.Children.Insert(firstSlotIndex, first);
        TileGrid.Children.Insert(firstSlotIndex + 1, second);

        // Margin 跟着各自新占的格子走：原来在前一格的 Margin 现在给挪到前面的那个磁贴用，
        // 原来在后一格的 Margin 给挪到后面的那个磁贴用。
        var frontMargin = launchIndex < quickStartIndex ? launchMargin : quickStartMargin;
        var backMargin = launchIndex < quickStartIndex ? quickStartMargin : launchMargin;
        first.Margin = frontMargin;
        second.Margin = backMargin;
    }

    /// <summary>
    /// 从配置里重新读取 IsDarkMode / AutoThemeCycleEnabled 并同步到「模式设置」/「自动循环」
    /// 两个按钮的勾选状态/文案，不触发保存、不重新应用配色（配色本身由调用方在改配置的同一
    /// 时刻已经调用过 ThemeService.ApplyForCurrentState，这里只是让按钮显示跟上最新状态）。
    /// 除了构造函数，MainWindow 的自动循环定时检查在真正切换了 IsDarkMode 之后也会调用一次，
    /// 保证首页按钮文案跟自动切换的结果保持同步，不会出现"实际已经变成深色模式，按钮却还
    /// 显示浅色"的不一致。
    /// </summary>
    public void RefreshThemeToggles()
    {
        var cfg = _owner.ConfigService.Config;

        _darkModeToggleInitializing = true;
        DarkModeToggle.IsChecked = cfg.IsDarkMode;
        UpdateDarkModeToggleText();
        _darkModeToggleInitializing = false;

        _autoThemeToggleInitializing = true;
        AutoThemeCycleToggle.IsChecked = cfg.AutoThemeCycleEnabled;
        UpdateAutoThemeCycleToggleText();
        _autoThemeToggleInitializing = false;

        _followSystemThemeToggleInitializing = true;
        FollowSystemThemeToggle.IsChecked = cfg.FollowSystemTheme;
        UpdateFollowSystemThemeToggleText();
        _followSystemThemeToggleInitializing = false;
    }

    private void UpdateModeToggleText()
    {
        ModeToggleText.Text = ModeToggle.IsChecked == true ? "高级模式" : "普通模式";
    }

    /// <summary>
    /// 首页右上角"普通模式/高级模式"开关：点击立即写回 cfg.AdvancedMode 并保存，
    /// 跟「设置」页 AdvancedModeCheck_Changed 是同一个配置项、同一份保存动作——不管从
    /// 哪一边切换，两边下次显示都会是最新状态（这一边不需要额外触发设置页控件显隐刷新，
    /// 那部分逻辑只在设置页自己打开时才需要跑）。
    /// </summary>
    private void ModeToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (_modeToggleInitializing) return;
        _owner.ConfigService.Config.AdvancedMode = ModeToggle.IsChecked == true;
        _owner.ConfigService.Save();
        UpdateModeToggleText();
    }

    private void UpdateDarkModeToggleText()
    {
        var isDark = DarkModeToggle.IsChecked == true;
        DarkModeToggleText.Text = isDark ? "深色模式" : "浅色模式";
        DarkModeToggleIcon.Text = isDark ? "\uD83C\uDF19" : "\u2600"; // 🌙 / ☀
    }

    /// <summary>
    /// 「模式设置」按钮：切换深色/浅色，只影响 cfg.IsDarkMode，不影响 cfg.UiSkin 选的色系
    /// （比如色系选了蓝色，这里点击只是在"蓝色系-浅"和"蓝色系-深"之间切）。点击立即写回
    /// 配置、保存，并调用 ThemeService 重新应用——保存后一秒内必须看到界面刷新，这里直接
    /// 同步调用 Apply，不存在异步延迟。
    ///
    /// 这是用户"手动"点的操作，即使当前「自动循环」是开启状态，也允许临时覆盖显示——
    /// 只是不会关闭自动循环本身，到下一个自动切换时间点，MainWindow 的定时检查还是会
    /// 按计划把 IsDarkMode 重新覆盖回去（见 MainWindow.ReevaluateAutoThemeCycle）。
    /// </summary>
    private void DarkModeToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (_darkModeToggleInitializing) return;
        var cfg = _owner.ConfigService.Config;
        cfg.IsDarkMode = DarkModeToggle.IsChecked == true;
        _owner.ConfigService.Save();
        UpdateDarkModeToggleText();

        ThemeService.ApplyForCurrentState(cfg.GuestModeEnabled, cfg.UiSkin, cfg.IsDarkMode, cfg.CustomAccentColor);
    }

    private void UpdateAutoThemeCycleToggleText()
    {
        AutoThemeCycleToggleText.Text = AutoThemeCycleToggle.IsChecked == true ? "自动循环：已开启" : "自动循环";
    }

    /// <summary>
    /// 「自动循环」开关：开启后由 MainWindow 的每分钟定时检查根据当前系统时间自动决定
    /// cfg.IsDarkMode；关闭后完全交还给用户手动控制，不再有任何自动覆盖。
    /// 点击立即写回配置、保存；刚打开的瞬间立即校验一次当前时间点应该是哪个模式并应用，
    /// 不需要等到下一次定时检查才生效（保存后一秒内必须看到界面刷新）。
    /// </summary>
    private void AutoThemeCycleToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (_autoThemeToggleInitializing) return;
        var cfg = _owner.ConfigService.Config;
        cfg.AutoThemeCycleEnabled = AutoThemeCycleToggle.IsChecked == true;
        // 开关状态一变化，"上次自动切换的时间段"记录就作废了：不管是刚打开（需要立即按当前
        // 时间校正一次）还是刚关闭（下次重新打开时不该沿用很久以前的旧记录），都清空。
        cfg.AutoThemeLastAppliedSlotStartHour = null;

        // 「跟随系统」是另一种互斥的自动来源，开启「自动循环」时顺带关掉它，不让两边同时
        // 抢着接管 IsDarkMode（见 AppConfig.FollowSystemTheme 注释）。
        if (cfg.AutoThemeCycleEnabled && cfg.FollowSystemTheme)
        {
            cfg.FollowSystemTheme = false;
            _followSystemThemeToggleInitializing = true;
            FollowSystemThemeToggle.IsChecked = false;
            UpdateFollowSystemThemeToggleText();
            _followSystemThemeToggleInitializing = false;
        }

        _owner.ConfigService.Save();
        UpdateAutoThemeCycleToggleText();

        _owner.ReevaluateAutoThemeCycle();
    }

    private void UpdateFollowSystemThemeToggleText()
    {
        FollowSystemThemeToggleText.Text = FollowSystemThemeToggle.IsChecked == true ? "跟随系统：已开启" : "跟随系统";
    }

    /// <summary>
    /// 「跟随系统」开关：开启后深浅色由 Windows 系统当前的应用主题设置决定，见
    /// MainWindow.ReevaluateFollowSystemTheme。点击立即写回配置、保存；刚打开的瞬间立即
    /// 按当前系统主题校正一次，不用等下一次系统主题变化事件才生效。
    /// 跟「自动循环」互斥：开启这个时顺带关掉「自动循环」，避免两边同时接管。
    /// </summary>
    private void FollowSystemThemeToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (_followSystemThemeToggleInitializing) return;
        var cfg = _owner.ConfigService.Config;
        cfg.FollowSystemTheme = FollowSystemThemeToggle.IsChecked == true;

        if (cfg.FollowSystemTheme && cfg.AutoThemeCycleEnabled)
        {
            cfg.AutoThemeCycleEnabled = false;
            cfg.AutoThemeLastAppliedSlotStartHour = null;
            _autoThemeToggleInitializing = true;
            AutoThemeCycleToggle.IsChecked = false;
            UpdateAutoThemeCycleToggleText();
            _autoThemeToggleInitializing = false;
        }

        _owner.ConfigService.Save();
        UpdateFollowSystemThemeToggleText();

        _owner.ReevaluateFollowSystemTheme();
    }

    private void UpdateGuestModeToggleText()
    {
        GuestModeToggleText.Text = GuestModeToggle.IsChecked == true ? "访客模式：已开启" : "访客模式";
    }

    /// <summary>
    /// 首页右上角访客模式开关：原来只能在「设置」页勾选/保存才生效，现在挪到首页后
    /// 点击立即生效——直接复用 MainWindow.RefreshGuestModeState 里"创建/清空临时账户 +
    /// 刷新侧边栏"的同一套逻辑，跟设置页保存时触发的是同一个方法，行为完全一致。
    /// 访客模式不影响界面配色（见 ThemeService 类注释：一切以用户当前的色系/明暗选择为准），
    /// 这里不需要额外调用 ThemeService。
    /// </summary>
    private void GuestModeToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (_guestToggleInitializing) return;

        if (GuestModeToggle.IsChecked == true && !_owner.ConfigService.Config.GuestModeEnabled)
        {
            // 开启访客模式一定通过一次重启进入，当前进程不做半途切换。
            if (!_owner.RequestGuestModeRestart())
            {
                _guestToggleInitializing = true;
                GuestModeToggle.IsChecked = false;
                _guestToggleInitializing = false;
                UpdateGuestModeToggleText();
            }
            return;
        }

        // 访客会话中手动关闭可立即恢复正常账户；磁盘本来也始终保存 false。
        _owner.ConfigService.Config.GuestModeEnabled = false;
        _owner.ConfigService.Save();
        _owner.RefreshGuestModeState();
        UpdateGuestModeToggleText();
    }

    // 磁贴点击：全部转发到 MainWindow 已有的公开导航方法/事件处理方法，不重复实现导航逻辑。
    // "启动游戏"磁贴直接调用 MainWindow.Launch_Click（已改成 public，见 MainWindow.xaml.cs），
    // 复用同一套防手滑冷却状态，跟左下角"启动游戏"按钮完全一致的行为。

    /// <summary>
    /// 首页右上角简洁模式开关：跟「设置」页里的同款开关共享同一个配置项
    /// （cfg.SimplifiedModeEnabled），点击立即写回 + 保存，统一走公开的
    /// _owner.ApplySimplifiedModeChanged() 刷新侧边栏/处理当前页面，不直接调用
    /// MainWindow 内部的 RefreshSimplifiedModeNavVisibility。
    /// </summary>
    private void OpenExperimentalPreview_Checked(object sender, RoutedEventArgs e)
    {
        if (_previewToggleSyncing) return;

        // 已经处在"重启进入的新界面预览"会话里：这个开关本来就是靠 MarkAsMainWindowPreviewSession
        // 同步成选中状态的，不是用户点出来的，不应该再弹一次确认框/再重启一次。
        if (_isMainWindowPreviewSession) return;

        if (!MessageBoxDialog.ShowConfirm(
            "新界面预览是实验性功能，可能存在显示、交互或稳定性问题。开启后会重启启动器，" +
            "重启后的新窗口会直接进入新界面预览，同时保留完整侧边栏，所有按钮都可以正常点击、正常导航。" +
            "是否重启并打开？",
            "实验性功能"))
        {
            // 用户取消确认框：按钮不应该停在"已开启"（蓝色）状态，改回浅色但不能再触发
            // 一次 Unchecked 里的重启逻辑（本来就没真正开启），用 _previewToggleSyncing 屏蔽掉。
            _previewToggleSyncing = true;
            PreviewToggle.IsChecked = false;
            _previewToggleSyncing = false;
            return;
        }

        // 不再套一层独立的浮动预览窗口（没有侧边栏、按钮点不动、容易套娃假死）：
        // 直接重启整个启动器，新进程的 MainWindow 用完整的自身（侧边栏 + 所有导航按钮都在）
        // 直接展示新界面预览，见 MainWindow.RequestPreviewModeRestart。重启失败时把开关
        // 复位回浅色，避免停在"看起来已开启但其实什么都没发生"的状态。
        if (!_owner.RequestPreviewModeRestart())
        {
            _previewToggleSyncing = true;
            PreviewToggle.IsChecked = false;
            _previewToggleSyncing = false;
        }
    }

    private void OpenExperimentalPreview_Unchecked(object sender, RoutedEventArgs e)
    {
        if (_previewToggleSyncing) return;

        if (_isMainWindowPreviewSession)
        {
            // 关闭预览：同样走重启，而不是简单地在当前进程里切回默认首页——保证"关闭后"
            // 跟"从来没开过预览"是完全一致的干净状态（不带任何预览相关的隐藏启动参数），
            // 新窗口只会打开原有默认界面，不会再打开新界面或其它界面。重启失败时把开关
            // 复位回"已选中"，因为预览会话其实还在继续，没有真的退出。
            if (!_owner.RequestExitPreviewModeRestart())
            {
                _previewToggleSyncing = true;
                PreviewToggle.IsChecked = true;
                _previewToggleSyncing = false;
            }
            return;
        }

        // 走到这里说明：当前不在"MainWindow 直接展示预览"的会话里，且不是代码同步触发的
        // Unchecked（前面已经 return 掉了）——也就是这份 HomePage 本身处于正常模式，
        // 但它的开关却被以某种方式取消选中。正常模式下开关默认就是未选中，点开时走的是
        // 上面 OpenExperimentalPreview_Checked（要么重启进入预览、要么弹确认框取消后复位），
        // 不会有"正常模式下开关先被选中、再单独触发一次 Unchecked"这条路径，所以这里
        // 不需要做任何事——历史上这里曾经维护一个指向旧版独立浮动预览窗口的引用并在此关闭它，
        // 那个方案已经被上面"整个进程重启"的方案取代，浮动窗口那条代码路径本身也早就没有
        // 地方会走到了，直接删掉，不留一个永远是 null、只会产生"从未赋值"编译警告的死字段。
    }

    /// <summary>
    /// 供 MainWindow.ShowExperimentalPreview 在"以 --preview-session 重启后的这次启动"里，
    /// 把首页直接当成新界面预览展示时调用一次：只是把开关同步成"已选中"，侧边栏、标题栏、
    /// 每一个导航按钮都还是 MainWindow 原生的那一套，天然可点，不做任何禁用。
    /// 跟 <see cref="ConfigureAsEmbeddedPreview"/>（旧的浮动窗口套娃场景）刻意区分开，
    /// 那边需要锁死按钮防止再套一层，这边完全不需要。
    /// </summary>
    public void MarkAsMainWindowPreviewSession()
    {
        _isMainWindowPreviewSession = true;
        _previewToggleSyncing = true;
        PreviewToggle.IsChecked = true;
        _previewToggleSyncing = false;
        PreviewToggle.ToolTip = "点击关闭新界面预览（会重启启动器回到默认界面）";
    }

    /// <summary>
    /// 供 ExperimentalPreviewWindow 在把这个 HomePage 实例塞进自己内容区之后调用一次。
    ///
    /// 根因：预览窗口内部是一份全新的 HomePage 实例，它自己的 PreviewToggle 默认是未选中——
    /// 但此时"新界面预览"其实已经真正打开了（就是承载它的这个预览窗口本身）。之前没有同步
    /// 这个状态，会出现两个问题：
    /// 1. 按钮显示状态不对："已经打开了"却显示成"没打开"，容易误导用户再点一次；
    /// 2. 更严重的是，如果用户真的点了这个内层按钮，会再触发一次
    ///    OpenExperimentalPreview_Checked：确认框走的是 OverlayDialogService，只认全局唯一的
    ///    MainWindow 宿主——而这个内层 HomePage 挂在一个盖在 MainWindow 上面的独立预览窗口里，
    ///    确认框会渲染到被预览窗口挡住的 MainWindow 上，用户看不见也点不到，
    ///    DispatcherFrame 局部消息泵却在等它关闭，界面就"卡住"了，表现为必须关掉整个启动器
    ///    重新启动才能恢复——这正是套娃（预览里再开一层预览）导致的假死。
    ///
    /// 修复方式：把内层按钮直接锁定成"已选中且不可再点"，从根上让套娃这条路径永远走不到，
    /// 而不是等它触发了再补救。
    /// </summary>
    public void ConfigureAsEmbeddedPreview()
    {
        _previewToggleSyncing = true;
        PreviewToggle.IsChecked = true;
        _previewToggleSyncing = false;
        PreviewToggle.IsEnabled = false;
        PreviewToggle.ToolTip = "当前正处于新界面预览窗口中，无法在预览里再次打开预览";
    }

    private void SimplifiedModeToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (_simplifiedToggleInitializing) return;

        _owner.ConfigService.Config.SimplifiedModeEnabled = SimplifiedModeToggle.IsChecked == true;
        _owner.ConfigService.Save();
        _owner.ApplySimplifiedModeChanged();
    }

    private void TileLaunch_Click(object sender, RoutedEventArgs e) => _owner.Launch_Click(sender, e);

    private void TileAccounts_Click(object sender, RoutedEventArgs e) => _owner.NavigateToAccounts();

    private void TileDownload_Click(object sender, RoutedEventArgs e)
    {
        // 需求 1/4 号手段同样覆盖"下载"入口：跟 TileLaunch_Click 共用 MainWindow.Launch_Click
        // 里已经接好的那次拦截判断不一样，这里是单独的磁贴（不经过 Launch_Click），
        // 所以在导航之前自己再判断一次。
        if (AprilFoolsUi.TryInterceptLaunchOrDownload(_owner)) return;
        _owner.NavigateToDownloadCenter();
    }

    /// <summary>
    /// 首页磁贴改动：原来这个位置是"Mod 管理"，现在换成"一键开始游戏"（打开
    /// QuickStartWizardWindow，账户/文件夹/版本/加载器/Mod/资源包一步到位）——按用户要求，
    /// 首页一等入口位优先给"一键启动"，Mod 管理仍然可以从「下载中心」进入，不是被删除，
    /// 只是不再单独占首页磁贴位。
    /// </summary>
    private void TileQuickStart_Click(object sender, RoutedEventArgs e)
    {
        var wizard = new QuickStartWizardWindow(_owner);
        wizard.ShowDialog();
    }

    private void TileServerManager_Click(object sender, RoutedEventArgs e) => _owner.NavigateToServerManager();

    private void TileSettings_Click(object sender, RoutedEventArgs e) => _owner.NavigateToSettings();

    /// <summary>
    /// 顶部「🌐 语言」按钮：打开独立的语言选择弹窗（LanguageSelectDialog）。选择后弹窗内部
    /// 自己完成保存+应用+关闭，这里不需要处理返回值或做任何后续刷新——语言切换后的界面
    /// 刷新由 LocalizationService.Apply 里复用的 ThemeService 窗口刷新逻辑统一处理，
    /// 首页这里不用额外调用什么方法。
    /// </summary>
    private void LanguageEntryButton_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new LanguageSelectDialog(_owner.ConfigService);
        OverlayDialogService.ShowModal(dlg);
    }
}
