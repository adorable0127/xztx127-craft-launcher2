﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using XCL2.App.Models;
using XCL2.App.Views;

namespace XCL2.App.Services;

public enum DownloadQueueItemStatus
{
    Downloading,
    Paused,
    Completed,
    Failed,
    Canceled
}

/// <summary>
/// 标题栏下载列表里的单个条目。暂停/继续 不是真正的"字节级暂停"（那需要把
/// DownloadService 内部按 chunk 写盘的循环整个改成可挂起状态机，改动面太大、
/// 风险也高），而是复用 DownloadService 本来就有的行为："文件已存在且校验通过
/// 就跳过，不重新下载"——所以这里的"暂停"实际是：取消当前正在跑的这次下载
/// （已经完整下载并校验通过的文件不会被删，只有正在写的那个 .part 分片会被
/// DownloadService 自己清理掉），"继续"则是用同样的参数重新调用一次安装方法，
/// 已经装好的部分会被跳过，效果上等价于"从中断点继续"，只是没有字节级精确续传。
/// </summary>
public sealed class DownloadQueueItem : INotifyPropertyChanged
{
    public Guid Id { get; } = Guid.NewGuid();
    public string Name { get; }

    private double _progressPercent;
    private bool _isIndeterminate = true;
    public bool IsIndeterminate
    {
        get => _isIndeterminate;
        set { _isIndeterminate = value; OnChanged(); }
    }
    public double ProgressPercent
    {
        get => _progressPercent;
        set { _progressPercent = value; OnChanged(); }
    }

    private string _statusText = "等待中...";
    public string StatusText
    {
        get => _statusText;
        set { _statusText = value; OnChanged(); }
    }

    private DownloadQueueItemStatus _status = DownloadQueueItemStatus.Downloading;
    public DownloadQueueItemStatus Status
    {
        get => _status;
        set { _status = value; OnChanged(); NotifyControls(); }
    }

    /// <summary>该任务是否允许暂停。安装加载器这类不能安全中断后续传的任务设为 false，界面上不会出现暂停按钮。</summary>
    public bool SupportsPause { get; init; } = true;
    public bool SupportsRetry { get; init; } = true;
    public bool SupportsCancel { get; init; } = true;
    private bool _isRunning;
    public bool IsRunning
    {
        get => _isRunning;
        internal set { _isRunning = value; OnChanged(); NotifyControls(); }
    }
    public bool CanPause => SupportsPause && IsRunning && Status == DownloadQueueItemStatus.Downloading;
    public bool CanResume => !IsRunning && (Status == DownloadQueueItemStatus.Paused ||
        (SupportsRetry && Status == DownloadQueueItemStatus.Failed));
    public bool CanPauseOrResume => CanPause || CanResume;
    public bool CanCancel => !IsRunning || (SupportsCancel && Status != DownloadQueueItemStatus.Canceled);
    public string CancelLabel => IsRunning || Status == DownloadQueueItemStatus.Paused ? "取消" : "移除";
    internal bool PauseRequested;
    internal TaskCompletionSource<DownloadQueueItemStatus> CompletionSource = NewCompletionSource();
    internal static TaskCompletionSource<DownloadQueueItemStatus> NewCompletionSource() =>
        new(TaskCreationOptions.RunContinuationsAsynchronously);
    /// <summary>当前这次执行的真实结束状态，不等待完成条目自动收起。</summary>
    public Task<DownloadQueueItemStatus> Completion => CompletionSource.Task;
    public Exception? LastError { get; internal set; }
    public string? CompletionText { get; set; }
    private void NotifyControls()
    {
        OnChanged(nameof(CanPause)); OnChanged(nameof(CanResume)); OnChanged(nameof(CanPauseOrResume));
        OnChanged(nameof(CanCancel)); OnChanged(nameof(CancelLabel));
    }

    /// <summary>驱动本次下载的取消令牌源。暂停/取消都通过 Cancel() 它来打断当前
    /// await 中的下载调用；暂停之后如果要继续，会 new 一个新的 Cts 重新跑。</summary>
    internal CancellationTokenSource Cts;

    /// <summary>重新发起这个条目对应的下载调用（拿新的 CancellationToken 以及条目自身，
    /// 后者主要是方便调用方拿 CreateProgress() 把进度接回来），由 DownloadCenterPage、
    /// BedrockPage 等发起下载的地方在注册条目时提供，这里不关心具体是"游戏版本"
    /// "整合包""基岩版客户端"还是别的什么类型的下载。</summary>
    internal readonly Func<DownloadQueueItem, CancellationToken, Task> ResumeAction;

    /// <summary>
    /// 这条下载任务最终会产出/修改的那个游戏版本 ID（比如"安装 1.20.1"就是 1.20.1，
    /// 整合包安装则是它写入的那个版本目录名）。只有"装完之后会多出一个可启动版本"的任务
    /// 才会赋值；下载 Mod、下载 Java、下载服务端核心这些不产出可启动版本的任务保持 null。
    ///
    /// 存在的唯一目的：让"启动游戏"能判断出**当前选中的这个版本正在被下载/安装**，
    /// 从而拦下这一次启动（一个只装了一半的版本目录，启动出来的必然是崩溃或者缺文件的
    /// 半成品，弹个原生 Java 崩溃窗口比直接告诉用户"还在装，等一下"糟糕得多）。
    /// 注意这**不是**"下载期间禁止启动任何游戏"——跟这条下载无关的其它版本照常可以启动，
    /// 见本文件下方 FindActiveForVersion 的注释。
    /// </summary>
    public string? TargetVersionId { get; init; }

    /// <summary>这条下载任务安装到哪个 .minecraft 文件夹。同一个版本号可以同时存在于多个
    /// 游戏文件夹里，只比版本 ID 会误伤——用户完全可能一边在 A 文件夹装 1.20.1，
    /// 一边启动 B 文件夹里早就装好的 1.20.1。为 null 时退化成只比版本 ID。</summary>
    public string? TargetFolderPath { get; init; }

    private readonly HashSet<string> _installationTargets = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>登记这条任务实际会写入的版本 ID。加载器安装的最终版本名要到安装过程中才能确定
    /// （自定义实例名、Forge 解析出的目录名等），所以允许在运行中追加，可多次调用。</summary>
    public void RegisterInstallationTarget(string? versionId)
    {
        if (string.IsNullOrWhiteSpace(versionId)) return;
        DownloadQueueService.Instance.RegisterInstallationTarget(this, versionId.Trim());
    }
    internal void AddInstallationTarget(string versionId)
    {
        lock (_installationTargets) _installationTargets.Add(versionId);
    }

    /// <summary>该任务是否正在写入指定版本（初始目标或运行中登记的目标）。</summary>
    internal bool TargetsVersion(string versionId)
    {
        if (!string.IsNullOrWhiteSpace(TargetVersionId) &&
            string.Equals(TargetVersionId, versionId, StringComparison.OrdinalIgnoreCase)) return true;
        lock (_installationTargets) return _installationTargets.Contains(versionId.Trim());
    }

    public DownloadQueueItem(string name, CancellationTokenSource cts, Func<DownloadQueueItem, CancellationToken, Task> resumeAction)
    {
        Name = name;
        Cts = cts;
        ResumeAction = resumeAction;
    }

    // ===== 下载详情（剩余时间/当前速度/大小），见 AppConfig.DownloadPopupShowDetailStats 注释 =====
    // 注意：现有 ProgressInfo.Done/Total 在大多数阶段报告的是"文件个数"而不是字节数
    // （DownloadService 里实际的网络字节拷贝走 CopyToAsync，没有逐字节上报进度），
    // 所以这里的"速度"是按 Done 这个计数单位、用两次进度回调之间的时间差算出来的
    // "单位/秒"，"大小"栏也是同一套计数单位（多数场景下就是"文件数"，例如
    // "下载依赖库 3/40" 时显示的是"每秒约 X 个文件"和"剩余 37 个"，不是精确字节数/MB）。
    // 如果后续要精确到字节，需要在 DownloadService/GenericFileDownloadService 等实际
    // 拷贝网络流的地方额外接一路字节级进度回调，属于更大改动，这里先把"能拿到的进度
    // 粒度"如实、稳定地展示出来。
    private DateTime _lastSampleTime = DateTime.MinValue;
    private int _lastSampleDone;
    private double _unitsPerSecond;
    private string? _lastStage;

    private string _detailText = "";
    /// <summary>格式化好的详情行文本（剩余时间 · 当前速度 · 大小），按
    /// AppConfig.DownloadPopupSizeDisplayMode 决定"大小"这一段展示剩余/已下载/两者。
    /// 直接绑定给 MainWindow 下载气泡里新增的详情 TextBlock。</summary>
    public string DetailText
    {
        get => _detailText;
        private set { _detailText = value; OnChanged(); }
    }

    private void UpdateDetail(int done, int total)
    {
        var now = DateTime.UtcNow;
        if (_lastSampleTime != DateTime.MinValue)
        {
            var elapsed = (now - _lastSampleTime).TotalSeconds;
            // 至少间隔 0.4s 才重新采样速度，避免同一批回调打太密时速度抖动到没法看。
            if (elapsed >= 0.4)
            {
                var deltaDone = done - _lastSampleDone;
                var instant = deltaDone > 0 ? deltaDone / elapsed : 0;
                // 简单指数平滑，减少速度数字来回跳。
                _unitsPerSecond = _unitsPerSecond <= 0 ? instant : _unitsPerSecond * 0.7 + instant * 0.3;
                _lastSampleTime = now;
                _lastSampleDone = done;
            }
        }
        else
        {
            _lastSampleTime = now;
            _lastSampleDone = done;
        }

        var remaining = Math.Max(0, total - done);
        var speedText = _unitsPerSecond > 0.05 ? $"{_unitsPerSecond:0.#}/s" : "--";
        string etaText;
        if (_unitsPerSecond > 0.05 && remaining > 0)
        {
            var etaSeconds = remaining / _unitsPerSecond;
            etaText = etaSeconds < 60 ? $"{etaSeconds:0}秒"
                : etaSeconds < 3600 ? $"{etaSeconds / 60:0}分{etaSeconds % 60:0}秒"
                : $"{etaSeconds / 3600:0}时{etaSeconds % 3600 / 60:0}分";
        }
        else etaText = total > 0 && done >= total ? "已完成" : "计算中...";

        var mode = DownloadQueueService.Instance?.Config?.DownloadPopupSizeDisplayMode ?? 0;
        var sizeText = mode switch
        {
            1 => $"已完成 {done}/{total}",
            2 => $"已完成 {done}/{total}（剩余 {remaining}）",
            _ => $"剩余 {remaining}/{total}",
        };

        DetailText = total > 0 ? $"剩余时间 {etaText} · {speedText} · {sizeText}" : "";
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnChanged([CallerMemberName] string? n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));

    /// <summary>把这个条目包成一个 IProgress&lt;ProgressInfo&gt;，方便直接传给下载/解压/安装
    /// 这类本来就接受 ProgressInfo 回调的方法（DownloadService、BedrockClientDownloadService、
    /// BedrockContentService 等全项目统一用的这个类型），不需要调用方自己再手写一遍
    /// "算百分比 + 切 UI 线程 + 更新 StatusText" 的样板代码。</summary>
    public IProgress<ProgressInfo> CreateProgress() => new Progress<ProgressInfo>(info =>
    {
        if (!IsRunning || Status != DownloadQueueItemStatus.Downloading) return;
        if (_lastStage != info.Stage || info.Done < _lastSampleDone)
        {
            _lastStage = info.Stage;
            _lastSampleTime = DateTime.MinValue;
            _unitsPerSecond = 0;
        }
        IsIndeterminate = info.Total <= 0;
        var pct = info.Total > 0 ? (double)info.Done / info.Total * 100 : 0;
        ProgressPercent = Math.Clamp(pct, 0, 100);
        StatusText = info.Total > 0
            ? $"{info.Stage} {info.Done}/{info.Total}" + (string.IsNullOrEmpty(info.CurrentFile) ? "" : $" {info.CurrentFile}")
            : info.Stage;
        UpdateDetail(info.Done, info.Total);
    });
}

/// <summary>
/// 全局单例：游戏、资源、运行时、启动前补全与驱动任务统一登记。
/// 启动前必需的下载会等待真实结果；无关版本的下载不会阻塞启动。
///
/// 后来补的一条例外（也只有这一条）：**正在下载/安装中的那个版本本身**不能启动。
/// 上面那条"互不阻塞"说的是"下载 A 的时候可以启动 B"，这没问题；但如果用户选中的
/// 恰恰就是此刻正在被写入的那个版本目录，启动出来的必然是缺 libraries/assets 的
/// 半成品，结果是一个用户看不懂的原生 Java 崩溃窗口。与其让它崩，不如明确告诉用户
/// "这个版本还在装，装完再启动"。判断入口见 FindActiveForVersion，拦截点在
/// MainWindow.LaunchInternalAsync。跟这条下载无关的其它版本仍然照常可以启动。
/// </summary>
public sealed class DownloadQueueService
{
    public static DownloadQueueService Instance { get; } = new();

    /// <summary>由 MainWindow 启动时赋值一次，供 DownloadQueueItem.UpdateDetail 读取
    /// DownloadPopupSizeDisplayMode 等设置项——这个单例服务本身不持有 ConfigService，
    /// 避免额外拉一份 DI/构造依赖，直接让宿主窗口把当前配置对象塞进来即可（引用类型，
    /// 设置页保存后原地修改同一个 AppConfig 实例，这里读到的自然是最新值）。</summary>
    public AppConfig? Config { get; set; }

    public ObservableCollection<DownloadQueueItem> Items { get; } = new();

    public bool HasActive => Items.Any(i => i.IsRunning || i.Status == DownloadQueueItemStatus.Paused);

    /// <summary>
    /// 找出"正在下载/安装 <paramref name="versionId"/> 这个版本"的队列条目，没有就返回 null。
    ///
    /// 为什么 Paused 也算：本项目的"暂停"在实现上是取消当前这次下载、保留已装好的文件
    /// （见 DownloadQueueItem 类头注释），所以暂停中的版本目录同样是不完整的半成品，
    /// 启动它跟启动一个下载中的版本一样会崩。Completed/Failed/Canceled 则不拦——
    /// 失败/取消的那次安装用户自己看得到状态，要不要冒险启动是他的选择，不该由启动器替他否决。
    ///
    /// 文件夹为空时退化成只比版本 ID：宁可在这种少见情况下多拦一次（提示里会写清楚原因，
    /// 用户等几秒就好），也不要漏拦导致真的启动了一个装了一半的版本。
    /// </summary>
    public DownloadQueueItem? FindActiveForVersion(string? folderPath, string? versionId)
    {
        if (string.IsNullOrWhiteSpace(versionId)) return null;

        return Items.FirstOrDefault(i =>
            (i.IsRunning || i.Status == DownloadQueueItemStatus.Paused) &&
            i.TargetsVersion(versionId) &&
            (string.IsNullOrWhiteSpace(i.TargetFolderPath) || string.IsNullOrWhiteSpace(folderPath) ||
             string.Equals(NormalizeFolder(i.TargetFolderPath), NormalizeFolder(folderPath), StringComparison.OrdinalIgnoreCase)));
    }

    /// <summary>把路径归一成可比较的形式（去掉结尾分隔符、转成绝对路径）。
    /// 下载登记方拿到的路径和 cfg.SelectedFolderPath 可能一个带结尾反斜杠一个不带，
    /// 直接字符串比会漏判，那样拦截就形同虚设。</summary>
    private static string NormalizeFolder(string path)
    {
        try { return Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar); }
        catch { return path.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar); }
    }

    private DownloadQueueService() { }

    internal void RegisterInstallationTarget(DownloadQueueItem item, string versionId) => RunOnUi(() =>
    {
        var existing = FindActiveForVersion(item.TargetFolderPath, versionId);
        if (existing != null && existing != item)
            throw new InvalidOperationException($"「{versionId}」已有下载或补全任务，无法同时写入该版本。");
        item.AddInstallationTarget(versionId);
    });

    /// <summary>登记一个新的下载条目并立即开始跑。调用方只需要把"怎么下载"包成
    /// resumeAction，其余的状态流转、异常吞掉、UI 线程调度都在这里统一处理，
    /// 不需要每个调用点各自重复一遍 try/catch。
    ///
    /// 需求："每个下载任务在开始下载时，在右下角做个气泡，提示：下载已开始"。
    /// 放在这里（登记入口的唯一出口）而不是分散在各个调用方里各自弹一次，能保证
    /// 不管这个任务是"安装游戏版本""下载 Mod/资源""基岩版客户端"还是别的什么，
    /// 只要走的是这条统一登记入口就一定会提示到，不会因为某个调用点忘了加而漏掉。
    /// 复用 ShowCompletionNotification 已经在用的 ToastService，跟"下载完成"提示
    /// 是同一套右下角气泡组件、视觉上连贯；用 Info 类型（不是 Success）跟"已完成"
    /// 区分开，避免用户扫一眼颜色就以为下载已经结束了。</summary>
    public DownloadQueueItem StartNew(string name, Func<DownloadQueueItem, CancellationToken, Task> resumeAction,
        string? targetVersionId = null, string? targetFolderPath = null, bool supportsPause = true,
        bool supportsRetry = true, bool supportsCancel = true)
    {
        var cts = new CancellationTokenSource();
        var item = new DownloadQueueItem(name, cts, resumeAction)
        {
            TargetVersionId = string.IsNullOrWhiteSpace(targetVersionId) ? null : targetVersionId,
            TargetFolderPath = string.IsNullOrWhiteSpace(targetFolderPath) ? null : targetFolderPath,
            SupportsPause = supportsPause,
            SupportsRetry = supportsRetry,
            SupportsCancel = supportsCancel
        };
        RunOnUi(() =>
        {
            if (FindActiveForVersion(targetFolderPath, targetVersionId) != null)
                throw new InvalidOperationException($"「{targetVersionId}」已有下载或补全任务，请等待该任务结束。");
            item.IsRunning = true;
            Items.Add(item);
            ToastService.ShowInfo($"{name}：下载已开始");
        });
        RunOnUi(() => { _ = RunAsync(item); });
        return item;
    }

    private async Task RunAsync(DownloadQueueItem item)
    {
        var attemptCts = item.Cts;
        var completion = item.CompletionSource;
        RunOnUi(() => { item.Status = DownloadQueueItemStatus.Downloading; item.StatusText = "下载中..."; });
        try
        {
            await item.ResumeAction(item, attemptCts.Token);
            attemptCts.Token.ThrowIfCancellationRequested();
            RunOnUi(() =>
            {
                item.Status = DownloadQueueItemStatus.Completed;
                item.StatusText = item.CompletionText ?? "已完成";
                item.ProgressPercent = 100;
                item.IsIndeterminate = false;
            });
        }
        catch (OperationCanceledException)
        {
            RunOnUi(() =>
            {
                item.Status = item.PauseRequested ? DownloadQueueItemStatus.Paused : DownloadQueueItemStatus.Canceled;
                item.StatusText = item.PauseRequested ? "已暂停" : "已取消";
            });
        }
        catch (Exception ex)
        {
            RunOnUi(() =>
            {
                item.LastError = ex;
                item.Status = DownloadQueueItemStatus.Failed;
                item.StatusText = $"失败：{ex.Message}";
            });
        }
        finally
        {
            RunOnUi(() => { item.IsRunning = false; item.IsIndeterminate = false; });
            completion.TrySetResult(item.Status);
            attemptCts.Dispose();
        }
        if (item.Status == DownloadQueueItemStatus.Completed)
        {
            RunOnUi(() => ShowCompletionNotification(item));
            await Task.Delay(TimeSpan.FromSeconds(item.CompletionText == null ? 4 : 15));
            RunOnUi(() => Items.Remove(item));
        }
    }

    /// <summary>登记必须完成才能继续的任务。失败/取消向调用方传播，队列仍保留对应状态。
    /// 不提供暂停或重试，避免调用方已结束后后台重试又触发启动或安装。</summary>
    public async Task<T> RunAndWaitAsync<T>(string name,
        Func<DownloadQueueItem, CancellationToken, Task<T>> action, CancellationToken ct = default,
        string? targetVersionId = null, string? targetFolderPath = null, bool supportsCancel = true)
    {
        ct.ThrowIfCancellationRequested();
        T result = default!;
        var item = StartNew(name, async (entry, token) => { result = await action(entry, token); },
            targetVersionId, targetFolderPath, supportsPause: false, supportsRetry: false, supportsCancel: supportsCancel);
        // 安装程序不可安全中断时仅取消调用方后续步骤；等安装进程真实退出后才释放任务。
        using var registration = supportsCancel ? ct.Register(() =>
        {
            // 取消回调不能同步等待 UI；否则 UI Dispose(registration) 与 Dispatcher.Invoke 会互等。
            var dispatcher = Application.Current?.Dispatcher;
            if (dispatcher != null && !dispatcher.CheckAccess())
                dispatcher.BeginInvoke(new Action(() => Cancel(item)));
            else Cancel(item);
        }) : default;
        var status = await item.Completion;
        ct.ThrowIfCancellationRequested();
        if (status == DownloadQueueItemStatus.Canceled)
            throw new OperationCanceledException("下载已取消。", ct);
        if (status != DownloadQueueItemStatus.Completed)
            throw item.LastError ?? new InvalidOperationException("下载未完成。");
        return result;
    }

    private void ShowCompletionNotification(DownloadQueueItem item)
    {
        try
        {
            if (item.Status != DownloadQueueItemStatus.Completed) return;

            var cfg = (Application.Current?.MainWindow as MainWindow)?.ConfigService.Config;
            if (cfg == null) return;

            bool noPopup = false;
            var completionMessage = item.CompletionText == null
                ? $"{item.Name} 完成" : $"{item.Name}：{item.CompletionText}";
            if (item.Name.StartsWith("安装 ") && cfg.GameVersionNoPopup) noPopup = true;
            else if (item.Name.StartsWith("下载 ") && cfg.CommunityResourceNoPopup) noPopup = true;
            else if (item.Name.StartsWith("整合包 ") && cfg.ModpackNoPopup) noPopup = true;

            if (noPopup)
            {
                if (cfg.DownloadNotifyMode == 1) // 角标
                {
                    ToastService.ShowSuccess(completionMessage);
                }
                else if (cfg.DownloadNotifyMode == 2) // Windows 通知
                {
                    ToastService.ShowSystemNotification(completionMessage, "下载完成");
                }
                // 3 = 不提示，什么都不做
            }
            else
            {
                ToastService.ShowSuccess(completionMessage);
            }
        }
        catch { }
    }

    public void Pause(DownloadQueueItem item)
    {
        if (!item.CanPause) return;
        item.PauseRequested = true;
        item.StatusText = "正在暂停...";
        item.Cts.Cancel();
    }

    public void Resume(DownloadQueueItem item)
    {
        if (!item.CanResume) return;
        var active = FindActiveForVersion(item.TargetFolderPath, item.TargetVersionId);
        if (active != null && active != item)
        {
            ToastService.ShowInfo("该版本已有下载或补全任务，请等待它结束后重试。");
            return;
        }
        item.PauseRequested = false;
        item.LastError = null;
        item.CompletionText = null;
        item.Cts = new CancellationTokenSource();
        item.CompletionSource = DownloadQueueItem.NewCompletionSource();
        item.IsRunning = true;
        _ = RunAsync(item);
    }

    public void Cancel(DownloadQueueItem item)
    {
        if (!item.CanCancel) return;
        if (!item.IsRunning)
        {
            item.Status = DownloadQueueItemStatus.Canceled;
            Items.Remove(item);
            return;
        }
        item.PauseRequested = false;
        item.Status = DownloadQueueItemStatus.Canceled;
        item.StatusText = "正在取消...";
        item.Cts.Cancel();
    }

    private static void RunOnUi(Action action)
    {
        var app = Application.Current;
        if (app?.Dispatcher == null || app.Dispatcher.CheckAccess())
            action();
        else
            app.Dispatcher.Invoke(action);
    }
}
